import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    private DatabaseConnection dbConnection;

    @Before
    public void setUp() {
        // Create a new DatabaseConnection instance before each test
        dbConnection = new DatabaseConnection();
    }

    @Test
    public void testValidLogin() {
        // Use valid credentials that are in the database
        String username = "admin";  // Replace with a valid username in your database
        String password = "password123";  // Replace with the correct password

        // Assert that the authentication is successful
        assertTrue("Valid user should be authenticated.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testInvalidUsername() {
        // Use an invalid username
        String username = "invalidUser";
        String password = "password123"; // Valid password

        // Assert that the authentication fails
        assertFalse("Invalid username should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testInvalidPassword() {
        // Use a valid username and an invalid password
        String username = "admin";  // Replace with a valid username
        String password = "wrongPassword";

        // Assert that the authentication fails
        assertFalse("Invalid password should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testEmptyUsername() {
        // Test empty username
        String username = "";
        String password = "password123"; // Valid password

        // Assert that authentication fails
        assertFalse("Empty username should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testEmptyPassword() {
        // Test empty password
        String username = "admin";  // Replace with a valid username
        String password = ""; // Empty password

        // Assert that authentication fails
        assertFalse("Empty password should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testBothEmpty() {
        // Test both empty username and password
        String username = "";
        String password = "";

        // Assert that authentication fails
        assertFalse("Empty username and password should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @Test
    public void testSQLInjection() {
        // Test for SQL injection attempt
        String username = "admin' OR '1'='1"; // SQL injection
        String password = "password123"; // Valid password

        // Assert that the authentication fails to prevent SQL injection
        assertFalse("SQL injection should not authenticate.", dbConnection.authenticateUser(username, password));
    }

    @After
    public void tearDown() {
        // Cleanup after each test if needed
        dbConnection = null;
    }
}
